import requests

def lambda_handler(event, context):
    url = "https://rebekahfowler.com" # <--- Change to your Render Website 
    try:
        response = requests.get(url)
        if response.status_code == 200:
            print(f"Website {url} accessed successfully.")
        else:
            print(f"Failed to access website {url}. Status code: {response.status_code}")
    except Exception as e:
        print(f"Failed to access website {url}. Exception: {e}")
